﻿
'    Kernel Simulator  Copyright (C) 2018-2020  EoflaOE
'
'    This file is part of Kernel Simulator
'
'    Kernel Simulator is free software: you can redistribute it and/or modify
'    it under the terms of the GNU General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    Kernel Simulator is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with this program.  If not, see <https://www.gnu.org/licenses/>.

Imports KS

<TestClass()> Public Class KernelTests

    ''' <summary>
    ''' Tests update fetching
    ''' </summary>
    <TestMethod()> Public Sub TestFetchKernelUpdates()
        Assert.IsNotNull(FetchKernelUpdates, "Can't fetch kernel updates. Make sure that your Internet connection is available. Returned null.")
    End Sub

    ''' <summary>
    ''' Tests garbage collection
    ''' </summary>
    <TestMethod()> Public Sub TestGarbageCollect()
        DisposeAll()
    End Sub

End Class