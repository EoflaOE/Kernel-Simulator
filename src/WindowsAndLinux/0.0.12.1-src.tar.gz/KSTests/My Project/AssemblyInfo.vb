﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("Kernel Simulator")>
<Assembly: AssemblyDescription("Simulates our future kernel.")>
<Assembly: AssemblyCompany("EoflaOE")>
<Assembly: AssemblyProduct("Kernel Simulator")>
<Assembly: AssemblyCopyright("Copyright © EoflaOE 2020")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

<Assembly: Guid("fe9eacdf-6ebd-4059-9ac9-75c2abc365b9")>

' <Assembly: AssemblyVersion("1.0.*")> 
<Assembly: AssemblyVersion("0.0.12.1")>
<Assembly: AssemblyFileVersion("1.0.12.1")>
