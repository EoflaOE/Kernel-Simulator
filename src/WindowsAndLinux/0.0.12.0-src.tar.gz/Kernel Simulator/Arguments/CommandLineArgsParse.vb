﻿
'    Kernel Simulator  Copyright (C) 2018-2020  EoflaOE
'
'    This file is part of Kernel Simulator
'
'    Kernel Simulator is free software: you can redistribute it and/or modify
'    it under the terms of the GNU General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    Kernel Simulator is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with this program.  If not, see <https://www.gnu.org/licenses/>.

Imports System.IO

Module CommandLineArgsParse

    Public availableCMDLineArgs() As String = {"testMod", "testInteractive", "debug", "args"}

    ''' <summary>
    ''' Parses the command line arguments
    ''' </summary>
    ''' <param name="arg">Argument</param>
    Sub ParseCMDArguments(ByVal arg As String)
        Try
            If Environment.GetCommandLineArgs.Length <> 0 And availableCMDLineArgs.Contains(arg) = True Then
                Dim argArgs As String = Environment.GetCommandLineArgs.Skip(2).ToArray.Join(" ")

                'Parse arguments
                If arg = "testMod" Then
                    StartParse(argArgs)
                    If scripts.Count = 0 Then
                        Environment.Exit(1)
                    Else
                        Environment.Exit(0)
                    End If
                ElseIf arg = "testInteractive" Then
                    InitTShell()
                    If TEST_ShutdownFlag Then Environment.Exit(0)
                ElseIf arg = "debug" Then
                    DebugMode = True
                ElseIf arg = "args" Then
                    argsOnBoot = True
                End If
            End If
        Catch ex As Exception
            W(DoTranslation("Error while parsing real command-line arguments: {0}", currentLang) + vbNewLine + "{1}", True, ColTypes.Err, ex.Message, ex.StackTrace)
            If arg = "testMod" Or arg = "createConf" Then
                Environment.Exit(1)
            End If
        End Try
    End Sub

End Module
