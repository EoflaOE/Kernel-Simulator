---
name: Ask a question
about: Ask us anything about KS.
title: "[Q&A] [FeatureName] - [Question]"
labels: ''
assignees: ''

---

### -+--> Type of question
- [ ] General
- [ ] API
- [ ] Commands
- [ ] Mods
- [ ] Others

### -+--> Ask here
