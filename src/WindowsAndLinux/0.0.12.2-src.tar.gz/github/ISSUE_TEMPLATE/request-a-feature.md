---
name: Request a feature
about: Suggest an idea to us.
title: "[ADD] [FeatureName] - [Feature]"
labels: ''
assignees: ''

---

### -+--> Description of new feature
<!--- Explain about a new feature here. --->


### -+--> What does it add?
- [ ] Command for shells
- [ ] New API functions
- [ ] Others

### -+--> If command for shells, specify what type of shell and what command
- Command name: 
    - [ ] FTP shell
    - [ ] Mail shell
    - [ ] RPC command
    - [ ] Test shell
    - [ ] Text editor shell
    - [ ] UESH shell (main shell)

### -+--> Have you tried doing it? If so, attach a mod file.
